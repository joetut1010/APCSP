function Bullet(x, y, team) {
    var self = this;
    self.x = x;
    self.team = team;
    self.r = 50

    // private properties
    var speed = 100;
    var body = color(255, 0, 0); // red

    // public functions
    self.control = function () {
        move();
        display();
    }
    self.x += speed;
}



function display() {
    fill(body);
    ellipse(self.x, self.y, self.r, self.r);
    setInterval(100);
}

function Ship(x1, y1, x2, y2, x3, y3) {

    var self = this;
    var x1 = x1;
    var y1 = y1;
    var x2 = x2;
    var y2 = y2;
    var x3 = x3;
    var y3 = y3;
    var c = color(255, 0, 185);
    var speed = 5;

    self.control = function () {
        keyboard();
        display();
    }

    function keyboard() {
        var SPACE_BAR = 32;

        if (keyIsDown(LEFT_ARROW)) {
            x1 -= speed;
            x2 -= speed;
            x3 -= speed;
        }
        if (keyIsDown(RIGHT_ARROW)) {
            x1 += speed;
            x2 += speed;
            x3 += speed;
        }
        if (keyIsDown(UP_ARROW)) {
            y1 -= speed;
            y2 -= speed;
            y3 -= speed;
        }
        if (keyIsDown(DOWN_ARROW)) {
            y1 += speed;
            y2 += speed;
            y3 += speed;
        }
        if (keyIsDown(SPACE_BAR)) {
            fire();
        }
    }

    var fire = function () {
        sprites.push(new Bullet(x1, y1));
    }

    function display() {
        fill(c);
        triangle(x1, y1, x2, y2, x3, y3);
    }
}

/*
function fire() {
    $("body").append($("<div>").addClass("bullet").css("bottom", 0));
}

$("input").click(fire);

function update() {
    $(".bullet").each(function () {
        var oldDown = $(this).offset().left;
        console.log(oldDown);
        $(this).css("bottom", oldDown + 1);
    });
}
setInterval(update, 200);
*/
